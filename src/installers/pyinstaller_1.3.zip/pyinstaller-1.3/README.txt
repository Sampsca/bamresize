_PyInstaller 1.3_
=================

Use
===
 See doc/Tutorial.txt

Installation in brief
=====================
 Non-Windows users should:
    cd source/linux

    python ./Make.py

    make

 Everyone should:
    python Configure.py

    python Makespec.py /path/to/yourscript.py

    python Build.py /path/to/yourscript.spec

    .done.

Major changes in this release
=============================
 See doc/CHANGES.txt

