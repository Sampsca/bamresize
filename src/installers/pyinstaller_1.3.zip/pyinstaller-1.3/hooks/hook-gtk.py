#

#Submited by Seth Remington (ticket#15)

hiddenimports = ['pango', 'atk', 'gobject', 'gtk.glade']

#
